﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kawiarnia1Biblioteka
{
    public enum TypDeseru
    {
        CiastoCzekoladowe,
        Sernik,
        Szarlotka
    }
    public class Deser : Produkt
    {
        public Deser()
        {
            Kategoria = Kategoria.Deser;
        }

        public TypDeseru TypDeseru { get; set; }

    }
}
