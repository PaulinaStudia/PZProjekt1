﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kawiarnia1Biblioteka
{
    public class ZasobService : IZasobService
    {
        private Dictionary<string, double> zasoby;
        private double domyslnaIlosc = 500;

        public ZasobService()
        {
            zasoby = new Dictionary<string, double>
            {
                {"Woda", 500},
                {"Mleko", 300},
                {"Kawa", 200},
                {"Ciasto czekoladowe", 10},
                {"Sernik", 10},
                {"Szarlotka", 10}
            };
        }

        public double PobierzIlosc(string nazwa)
        {
            return zasoby.ContainsKey(nazwa) ? zasoby[nazwa] : 0;
        }

        public void Uzupelnij(string nazwa)
        {
            if (zasoby.ContainsKey(nazwa))
            {
                switch (nazwa)
                {
                    case "Woda":
                    case "Mleko":
                        zasoby[nazwa] += 1000;
                        break;

                    case "Kawa":
                        zasoby[nazwa] += 250;
                        break;

                    case "Ciasto czekoladowe":
                    case "Sernik":
                    case "Szarlotka":
                        zasoby[nazwa] += 15;
                        break;

                    default:
                        zasoby[nazwa] += domyslnaIlosc;
                        break;
                }
            }
        }

        public void Wykorzystaj(string nazwa, double ilosc)
        {
            if (zasoby.ContainsKey(nazwa))
                zasoby[nazwa] -= ilosc;
        }
    }
}
