﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kawiarnia1Biblioteka
{
    public enum Kategoria
    {
        Wszystkie,
        Napój,
        Deser
    }

    public abstract class Produkt
    {
        public string Nazwa { get; set; }
        public decimal Cena { get; set; }
        public Kategoria Kategoria { get; set; }

        public override string ToString()
        {
            return $"{Nazwa} - {Cena} zł";
        }
    }
}
