﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kawiarnia1Biblioteka
{
    public static class Zasoby
    {
        public static int WodaML { get; set; } = 1000;
        public static int MlekoML { get; set; } = 1000;
        public static int KawaGram { get; set; } = 500;
        public static int PorcjeCiasta { get; set; } = 10;
    }
}
