﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kawiarnia1Biblioteka
{
    public class ProduktService : IProduktService
    {
        public List<Produkt> PobierzWszystkieProdukty()
        {
            List<Napoj> napoje = new List<Napoj>()
            {
                new Napoj { Nazwa = "Espresso", Cena = 9, TypNapoju = TypNapoju.Espresso},
                new Napoj { Nazwa = "Latte Macchiato", Cena = 14, TypNapoju = TypNapoju.LatteMacchiato },
                new Napoj { Nazwa = "Cappuccino", Cena = 12, TypNapoju = TypNapoju.Cappuccino },
                new Napoj { Nazwa = "Herbata czarna", Cena = 8, TypNapoju = TypNapoju.HerbataCzarna },
                new Napoj { Nazwa = "Herbata owocowa", Cena = 8, TypNapoju = TypNapoju.HerbataOwocowa },
            };

            List<Deser> desery = new List<Deser>()
            {
                new Deser { Nazwa = "Ciasto czekoladowe", Cena = 13, TypDeseru = TypDeseru.CiastoCzekoladowe},
                new Deser { Nazwa = "Sernik", Cena = 15, TypDeseru = TypDeseru.Sernik },
                new Deser { Nazwa = "Szarlotka", Cena = 14, TypDeseru = TypDeseru.Szarlotka }
            };

            List<Produkt> produkty = new List<Produkt>();
            produkty.AddRange(napoje);
            produkty.AddRange(desery);

            return produkty;
        }
    }
}
