﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kawiarnia1Biblioteka
{
    public class BrakProduktowException : Exception
    {
        public BrakProduktowException() : base("Nie wybrano żadnych produktów.")
        {
        }
    }
}
