﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kawiarnia1Biblioteka
{
    public class Skladnik
    {
        public string Nazwa { get; set; }
        public double PotrzebnaIlosc { get; set; }
        public double DostepnaIlosc { get; set; }
    }
}
