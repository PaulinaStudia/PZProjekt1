﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kawiarnia1Biblioteka
{
    public enum StatusZamowienia
    {
        Nowe,
        WTrakcie,
        Gotowe
    }
    public delegate void PowiadomienieHandler(string wiadomosc);
    public class Zamowienie
    {
        public int Id { get; set; }
        public List<Produkt> Produkty { get; set; } = new List<Produkt>();
        public DateTime DataZamowienia { get; set; } = DateTime.Now;
        public StatusZamowienia Status { get; set; } = StatusZamowienia.Nowe;

        public decimal CenaCalkowita => Produkty.Sum(p => p.Cena);

        public override string ToString()
        {
            return $"Zamowienie {Id}: {CenaCalkowita} zl ({Status})";
        }
    }
}
