﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kawiarnia1Biblioteka
{
    public interface IZasobService
    {
        double PobierzIlosc(string nazwa);
        void Uzupelnij(string nazwa);
        void Wykorzystaj(string nazwa, double ilosc);
    }
}
