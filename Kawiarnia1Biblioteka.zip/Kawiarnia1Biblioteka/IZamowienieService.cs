﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kawiarnia1Biblioteka
{
    public interface IZamowienieService
    {
        void DodajZamowienie(Zamowienie zamowienie);
        List<Zamowienie> PobierzZamowienia();
        void ZapiszDoPliku();
        void WczytajZPliku();
    }
}
