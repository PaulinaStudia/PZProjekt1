﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;

namespace Kawiarnia1Biblioteka
{
    public class ZamowienieService : IZamowienieService
    {
        private List<Zamowienie> zamowienia = new List<Zamowienie>();
        private readonly string sciezka = "zamowienia.json";

        public void DodajZamowienie(Zamowienie zamowienie)
        {
            zamowienia.Add(zamowienie);
        }

        public List<Zamowienie> PobierzZamowienia() => zamowienia;

        public void ZapiszDoPliku()
        {
            var json = JsonConvert.SerializeObject(zamowienia, Formatting.Indented);
            File.WriteAllText(sciezka, json);
        }

        public void WczytajZPliku()
        {
            if (File.Exists(sciezka))
            {
                var json = File.ReadAllText(sciezka);
                zamowienia = JsonConvert.DeserializeObject<List<Zamowienie>>(json) ?? new List<Zamowienie>();
            }
        }
    }
}
