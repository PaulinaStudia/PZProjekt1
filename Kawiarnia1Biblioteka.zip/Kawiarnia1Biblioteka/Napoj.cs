﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kawiarnia1Biblioteka
{
    public enum TypNapoju
    {
        Espresso,
        LatteMacchiato,
        Cappuccino,
        HerbataCzarna,
        HerbataOwocowa
    }
    public class Napoj : Produkt
    {
        public Napoj()
        {
            Kategoria = Kategoria.Napój;
        }

        public TypNapoju TypNapoju { get; set; }
    }
}
