﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Newtonsoft.Json;
using Kawiarnia1Biblioteka;

namespace Kaw1wpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private IProduktService produktService = new ProduktService();
        private IZamowienieService zamowienieService = new ZamowienieService();
        private IZasobService zasobService = new ZasobService();
        private static int licznikZamowien = 1;
        private List<Produkt> koszyk = new();

        public event PowiadomienieHandler Powiadom;

        public MainWindow()
        {
            InitializeComponent();
            Powiadom += PokazKomunikat;
            ListaProduktow.ItemsSource = produktService
                .PobierzWszystkieProdukty()
                .OrderBy(p => p.Nazwa)
                .ToList();

            KategoriaComboBox.ItemsSource = Enum.GetValues(typeof(Kategoria));
            KategoriaComboBox.SelectedIndex = 0;

        }

        private void PokazKomunikat(string wiadomosc)
        {
            MessageBox.Show(wiadomosc);
        }

        private void ZlozZamowienie_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var wybrane = ListaProduktow.SelectedItems.Cast<Produkt>().ToList();
                if (!wybrane.Any())
                    throw new BrakProduktowException();

                if (!koszyk.Any())
                    throw new BrakProduktowException();

                var zamowienie = new Zamowienie
                {
                    Id = licznikZamowien++,
                    Produkty = new List<Produkt>(koszyk)
                };

                zamowienieService.DodajZamowienie(zamowienie);
                Powiadom?.Invoke($"Dodano zamówienie: {zamowienie}");
                koszyk.Clear();
                OdswiezKoszyk();
                OdswiezWidoki();

            }
            catch (BrakProduktowException ex)
            {
                MessageBox.Show(ex.Message, "Błąd", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }


        private void Zapisz_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                zamowienieService.ZapiszDoPliku();
                Powiadom?.Invoke("Zapisano zamówienia do pliku.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd podczas zapisu do pliku: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Wczytaj_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                zamowienieService.WczytajZPliku();
                Powiadom?.Invoke("Wczytano zamówienia z pliku.");
                OdswiezWidoki();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd podczas wczytywania z pliku: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void OdswiezWidoki()
        {
            ListaZamowien.Items.Clear();
            ListaBarista.Items.Clear();

            foreach (var z in zamowienieService.PobierzZamowienia())
            {
                ListaZamowien.Items.Add(z.ToString());

                if (z.Status != StatusZamowienia.Gotowe)
                    ListaBarista.Items.Add(z);
            }
        }

        private void PrzygotujOkno_Click(object sender, RoutedEventArgs e)
        {
            var zamowienie = ListaBarista.SelectedItem as Zamowienie;
            if (zamowienie == null || zamowienie.Status != StatusZamowienia.Nowe)
            {
                Powiadom?.Invoke("Wybierz nowe zamówienie do przygotowania.");
                return;
            }

            var okno = new OknoPrzygotowania(zamowienie, zasobService);
            if (okno.ShowDialog() == true)
            {
                Powiadom?.Invoke($"Rozpoczęto przygotowanie zamówienia {zamowienie.Id}.");
                OdswiezWidoki();
            }
        }

        private void OznaczGotowe_Click(object sender, RoutedEventArgs e)
        {
            var zamowienie = ListaBarista.SelectedItem as Zamowienie;
            if (zamowienie == null || zamowienie.Status != StatusZamowienia.WTrakcie)
            {
                Powiadom?.Invoke("Wybierz zamówienie w trakcie, aby oznaczyć je jako gotowe.");
                return;
            }

            zamowienie.Status = StatusZamowienia.Gotowe;
            Powiadom?.Invoke($"Zamówienie {zamowienie.Id} gotowe do odbioru.");
            OdswiezWidoki();
        }

        private void Wyszukaj_Click(object sender, RoutedEventArgs e)
        {
            string nazwaFraza = PoleWyszukiwania.Text.Trim().ToLower();
            Kategoria wybranaKategoria = (Kategoria)KategoriaComboBox.SelectedItem;

            var wszystkieProdukty = produktService.PobierzWszystkieProdukty();

            List<Produkt> produkty;

            if (wybranaKategoria == Kategoria.Wszystkie)
            {
                produkty = wszystkieProdukty.Where(p => string.IsNullOrWhiteSpace(nazwaFraza) || p.Nazwa.ToLower().Contains(nazwaFraza))
                    .OrderBy(p => p.Nazwa)
                    .ToList();
            }
            else
            {
                produkty = wszystkieProdukty.Where(p =>
                    (string.IsNullOrWhiteSpace(nazwaFraza) || p.Nazwa.ToLower().Contains(nazwaFraza)) &&
                    (p.Kategoria == wybranaKategoria)
                ).OrderBy(p => p.Nazwa).ToList();
            }

            ListaProduktow.ItemsSource = produkty;
        }


        private void DodajDoKoszyka_Click(object sender, RoutedEventArgs e)
        {
            var wybrane = ListaProduktow.SelectedItems.Cast<Produkt>().ToList();
            foreach (var produkt in wybrane)
            {
                koszyk.Add(produkt);
            }

            OdswiezKoszyk();
        }

        private void UsunZKoszyka_Click(object sender, RoutedEventArgs e)
        {
            var wybrany = KoszykListBox.SelectedItem as Produkt;
            if (wybrany != null)
            {
                koszyk.Remove(wybrany);
                OdswiezKoszyk();
            }
        }

        private void OdswiezKoszyk()
        {
            KoszykListBox.ItemsSource = null;
            KoszykListBox.ItemsSource = koszyk;
        }
    }
}