﻿using Kawiarnia1Biblioteka;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Kaw1wpf
{
    public partial class OknoPrzygotowania : Window
    {
        private Zamowienie zamowienie;
        private IZasobService zasobService;
        private List<Skladnik> listaSkladnikow;

        public OknoPrzygotowania(Zamowienie zamowienie, IZasobService zasobService)
        {
            InitializeComponent();

            this.zamowienie = zamowienie;
            this.zasobService = zasobService;

            PrzygotujListeSkladnikow();
        }

        private void PrzygotujListeSkladnikow()
        {
            var wymagania = new Dictionary<string, double>();

            List<Napoj> listaNapoi = zamowienie.Produkty.OfType<Napoj>().ToList();
            List<Deser> listaDeserow = zamowienie.Produkty.OfType<Deser>().ToList();

            foreach (var napoj in listaNapoi)
            {
                switch (napoj.TypNapoju)
                {
                    case TypNapoju.Espresso:
                        DodajLubZwieksz(wymagania, "Woda", 30);
                        DodajLubZwieksz(wymagania, "Kawa", 9);
                        break;
                    case TypNapoju.LatteMacchiato:
                        DodajLubZwieksz(wymagania, "Woda", 30);
                        DodajLubZwieksz(wymagania, "Kawa", 9);
                        DodajLubZwieksz(wymagania, "Mleko", 150);
                        break;
                    case TypNapoju.Cappuccino:
                        DodajLubZwieksz(wymagania, "Woda", 25);
                        DodajLubZwieksz(wymagania, "Kawa", 8);
                        DodajLubZwieksz(wymagania, "Mleko", 125);
                        break;
                    case TypNapoju.HerbataCzarna:
                        DodajLubZwieksz(wymagania, "Woda", 250);
                        break;
                    case TypNapoju.HerbataOwocowa:
                        DodajLubZwieksz(wymagania, "Woda", 250);
                        break;
                    default:
                        break;
                }
            }


            foreach (var deser in listaDeserow)
            {
                switch (deser.TypDeseru)
                {

                    case TypDeseru.CiastoCzekoladowe:
                        DodajLubZwieksz(wymagania, "Ciasto czekoladowe", 1);
                        break;
                    case TypDeseru.Sernik:
                        DodajLubZwieksz(wymagania, "Sernik", 1);
                        break;
                    case TypDeseru.Szarlotka:
                        DodajLubZwieksz(wymagania, "Szarlotka", 1);
                        break;
                    default:
                        break;
                }
            }

            listaSkladnikow = wymagania.Select(kvp => new Skladnik
            {
                Nazwa = kvp.Key,
                PotrzebnaIlosc = kvp.Value,
                DostepnaIlosc = zasobService.PobierzIlosc(kvp.Key)
            }).ToList();

            ListaSkladnikow.ItemsSource = listaSkladnikow;
        }

        private void DodajLubZwieksz(Dictionary<string, double> dict, string klucz, double wartosc)
        {
            if (dict.ContainsKey(klucz))
                dict[klucz] += wartosc;
            else
                dict[klucz] = wartosc;
        }

        private void Uzupelnij_Click(object sender, RoutedEventArgs e)
        {
            if (sender is FrameworkElement fe && fe.Tag is string nazwa)
            {
                zasobService.Uzupelnij(nazwa);

                var skladnik = listaSkladnikow.FirstOrDefault(s => s.Nazwa == nazwa);
                if (skladnik != null)
                    skladnik.DostepnaIlosc = zasobService.PobierzIlosc(nazwa);

                ListaSkladnikow.Items.Refresh();
            }
        }

        private void Przygotuj_Click(object sender, RoutedEventArgs e)
        {
            foreach (var skladnik in listaSkladnikow)
            {
                if (skladnik.DostepnaIlosc < skladnik.PotrzebnaIlosc)
                {
                    MessageBox.Show($"Brak wystarczającej ilości składnika: {skladnik.Nazwa}");
                    return;
                }
            }

            foreach (var skladnik in listaSkladnikow)
            {
                zasobService.Wykorzystaj(skladnik.Nazwa, skladnik.PotrzebnaIlosc);
            }

            zamowienie.Status = StatusZamowienia.WTrakcie;

            DialogResult = true;
            Close();
        }

        private void Anuluj_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
